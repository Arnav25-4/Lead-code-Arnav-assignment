// LeetCode 378: Kth Smallest Element in a Sorted Matrix
// Difficulty: Medium
// Topics: Array, Binary Search, Matrix

class Solution {
    public int kthSmallest(int[][] matrix, int k) {
        int n = matrix.length;

        int low = matrix[0][0];
        int high = matrix[n - 1][n - 1];

        while (low < high) {
            int mid = low + (high - low) / 2;

            // Count elements <= mid using the sorted rows and columns.
            int count = 0;
            int row = n - 1;
            int col = 0;

            while (row >= 0 && col < n) {
                if (matrix[row][col] <= mid) {
                    count += row + 1;
                    col++;
                } else {
                    row--;
                }
            }

            if (count < k) {
                low = mid + 1;
            } else {
                high = mid;
            }
        }

        return low;
    }
}

/*
Example:
matrix = [[1, 5, 9],
          [10, 11, 13],
          [12, 13, 15]]
k = 8
Answer = 13

Time: O(n * log(maxValue - minValue))
Extra space: O(1)
*/
