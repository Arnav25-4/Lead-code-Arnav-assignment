// LeetCode 387: First Unique Character in a String
// Difficulty: Easy
// Topics: String, HashMap, Counting

import java.util.HashMap;
import java.util.Map;

class Solution {
    public int firstUniqChar(String s) {
        Map<Character, Integer> frequency = new HashMap<>();

        // First pass: count how often each character appears.
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            frequency.put(ch, frequency.getOrDefault(ch, 0) + 1);
        }

        // Second pass: return the index of the first character seen once.
        for (int i = 0; i < s.length(); i++) {
            if (frequency.get(s.charAt(i)) == 1) {
                return i;
            }
        }

        return -1;
    }
}

/*
Examples:
s = "leetcode"     -> 0
s = "loveleetcode" -> 2
s = "aabb"         -> -1

Time: O(n)
Extra space: O(1) for the fixed English alphabet;
             O(k) if considering k distinct characters.
*/
