# LeetCode Solutions (Java)

This folder contains Java solutions for:

| Problem | Title | Difficulty | Main concept |
|---|---|---|---|
| 378 | Kth Smallest Element in a Sorted Matrix | Medium | Binary Search |
| 387 | First Unique Character in a String | Easy | HashMap / Frequency Counting |

## Files
- `378-KthSmallestElement.java`
- `387-FirstUniqueCharacter.java`

## How to use
Open the relevant file and copy its solution into LeetCode's Java editor.
Each LeetCode submission uses the class name `Solution`, so submit the files separately.

These are standalone LeetCode submission snippets, not two classes intended to be compiled together in one Java project.
